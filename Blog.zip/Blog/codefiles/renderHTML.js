import { DB } from "./db.js";
export class renderHTML {
  constructor() {}
  printPosts() {
    let db = new DB();
    let posts = db.getPosts();

    let htmlBlock;
    htmlBlock = document.createElement("div");
    htmlBlock.setAttribute("class", "records");
    posts.forEach((post) => {
      let newRecord = document.createElement("div");
      newPost.innerText = `
Post Number: ${post.id}
Subject: ${post.subject}
Post: ${post.diary}
`;
      htmlBlock.appendChild(newPost);
    });
    return htmlBlock;
  }
}
