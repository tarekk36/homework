export class Post {
  id;
  date;
  subject;
  diary;
  constructor(date, subject, diary) {
    this.id = null;
    this.date = date;
    this.subject = subject;
    this.post = diary;
  }
}
