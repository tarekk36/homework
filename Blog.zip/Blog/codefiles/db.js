export class DB {
  constructor() {
    this.dbname = "blogposts";
    this.initDB();
  }
  addPost() {
    let existingPosts = this.getRecords();
    let newId = existingPosts.length;
    post.id = newId;
    existingPosts.push(record);
    localStorage.setItem(this.dbname, JSON.stringify(existingPosts));
  }
  deletePost(id) {
    let existingPosts = this.getPosts();
    existingPosts.splice(deletionID, 1);
    localStorage.setItem(this.dbname, JSON.stringify(existingPosts));
  }
  getPosts() {
    let posts;
    posts = localStorage.getItem(this.dbname);
    posts = JSON.parse(posts);
    return posts;
  }
  initDB() {
    if (localStorage.getItem(this.dbname) == null) {
      localStorage.setItem(this.dbname, "[]");
    }
  }
}
