import { renderHTML } from "./renderHTML.js";
import { Post } from "./post.js";
import { DB } from "./db.js";

class runIndex {
  constructor() {
    this.render();
  }
  render() {
    let newRender = new renderHTML();
    let htmlBlock = newRender.printPosts();
    document.getElementById("container").appendChild(htmlBlock);
  }
}
let newDb = new DB();
let newPost = new Post(1, "Trip", "africa trip");
newDb.addPost(newPost);

let newRun = new runIndex();
