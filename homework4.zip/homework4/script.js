let first = Number(prompt(`Add the first number`));
let second = Number(prompt(`Add the first number`));
if ((first % second) == 0) {
    alert('No Remainder')
} else {
   alert('There is a remainder');
}
