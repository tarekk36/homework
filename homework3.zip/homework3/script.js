let arr = [];
for (let i = 0; i < 10; i++) {
        arr.push(prompt(`enter ${i + 1} something`));
     }

     arr.forEach((val) =>{

        console.log(val);
     } );